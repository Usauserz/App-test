plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.example.livetranslate"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.livetranslate"
        minSdk = 26; targetSdk = 34; versionCode = 1; versionName = "1.0"
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.8.1")
    implementation("com.google.mlkit:text-recognition-chinese:16.0.1") // OCR offline (modelo embutido)
    implementation("com.google.mlkit:translate:17.0.3")                // tradução offline (modelo baixado 1x)
}
