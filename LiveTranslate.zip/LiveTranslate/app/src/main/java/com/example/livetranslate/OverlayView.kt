package com.example.livetranslate

import android.content.Context
import android.graphics.*
import android.text.*
import android.util.TypedValue
import android.view.View

/** Camada transparente, não-tocável, que desenha a tradução sobre o texto original. */
class OverlayView(c: Context, private val st: Settings) : View(c) {
    @Volatile private var items: List<Item> = emptyList()
    @Volatile private var sx = 1f
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

    fun boxes(): List<Rect> = items.map { it.box }
    fun submit(list: List<Item>, scale: Float) { items = list; sx = scale; invalidate() }

    override fun onDraw(cv: Canvas) {
        val dm = resources.displayMetrics
        tp.textSize = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, st.fontSp.toFloat(), dm)
        bg.color = Color.argb(st.opacity * 255 / 100, 15, 15, 15)
        val ox = st.offsetX * dm.density; val oy = st.offsetY * dm.density
        for (it in items) {
            val r = it.box
            val w = maxOf((r.width() * sx).toInt(), (130 * dm.density).toInt()).coerceAtMost(width - 8)
            val lay = StaticLayout.Builder.obtain(it.text, 0, it.text.length, tp, w).build()
            val x = (r.left * sx + ox).coerceIn(0f, (width - w).toFloat())
            val y = (r.top * sx + oy).coerceAtLeast(0f)
            val h = maxOf(lay.height.toFloat(), r.height() * sx)
            cv.drawRoundRect(x - 6, y - 2, x + w + 6, y + h + 2, 8f, 8f, bg)
            cv.save(); cv.translate(x, y); lay.draw(cv); cv.restore()
        }
    }
}
