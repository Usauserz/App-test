package com.example.livetranslate

import android.graphics.Bitmap
import android.graphics.Rect
import android.util.LruCache
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import kotlinx.coroutines.tasks.await

data class Item(val box: Rect, val text: String)

/** Ponto de extensão: qualquer fonte de texto (OCR, Accessibility, hook...) pode implementar isto. */
interface TextSource { suspend fun read(frame: Bitmap): List<Pair<Rect, String>> }

class OcrSource : TextSource {
    private val rec = TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
    private val han = Regex("\\p{IsHan}")
    override suspend fun read(frame: Bitmap) =
        rec.process(InputImage.fromBitmap(frame, 0)).await().textBlocks.mapNotNull { b ->
            val box = b.boundingBox ?: return@mapNotNull null
            val s = b.text.replace('\n', ' ').trim()
            if (han.containsMatchIn(s)) box to s else null   // ignora texto sem chinês (e o próprio overlay)
        }.take(25)
    fun close() = rec.close()
}

class TranslationEngine(private val st: Settings, private val source: TextSource = OcrSource()) {
    private var translator: Translator? = null
    private var tgt = ""
    private val cache = LruCache<String, String>(600)   // evita retraduzir/reconsumir CPU

    private fun tr(): Translator {
        if (translator == null || tgt != st.target) {
            translator?.close(); tgt = st.target
            translator = Translation.getClient(
                TranslatorOptions.Builder()
                    .setSourceLanguage(TranslateLanguage.CHINESE).setTargetLanguage(tgt).build())
        }
        return translator!!
    }

    /** Baixa o modelo uma única vez (~30 MB); depois tudo roda offline. */
    suspend fun prepare() { tr().downloadModelIfNeeded(DownloadConditions.Builder().build()).await() }

    suspend fun run(frame: Bitmap): List<Item> {
        val t = tr()
        return source.read(frame).map { (box, s) ->
            val key = "$tgt|$s"
            Item(box, cache.get(key) ?: t.translate(s).await().also { cache.put(key, it) })
        }
    }

    fun close() { (source as? OcrSource)?.close(); translator?.close() }
}
