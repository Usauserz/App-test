package com.example.livetranslate

import android.content.Context

/** Preferências lidas "ao vivo" pelo serviço e pelo overlay (mudanças valem sem reiniciar, exceto resolução OCR). */
class Settings(c: Context) {
    private val sp = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)
    private fun i(k: String, d: Int) = sp.getInt(k, d)
    private fun p(k: String, v: Int) = sp.edit().putInt(k, v).apply()

    var target: String
        get() = sp.getString("target", "en")!!
        set(v) = sp.edit().putString("target", v).apply()
    var fontSp: Int
        get() = i("font", 14)
        set(v) = p("font", v)
    var opacity: Int
        get() = i("opacity", 85)
        set(v) = p("opacity", v)
    var intervalMs: Int
        get() = i("interval", 800)
        set(v) = p("interval", v)
    var offsetX: Int
        get() = i("ox", 0)
        set(v) = p("ox", v)
    var offsetY: Int
        get() = i("oy", 0)
        set(v) = p("oy", v)
    var ocrScalePct: Int
        get() = i("scale", 60)
        set(v) = p("scale", v)
}
