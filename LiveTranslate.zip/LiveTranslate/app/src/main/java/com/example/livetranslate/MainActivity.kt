package com.example.livetranslate

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var st: Settings
    private val langs = listOf("English" to "en", "Português" to "pt", "Español" to "es",
        "Français" to "fr", "Русский" to "ru", "Bahasa Indonesia" to "id")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        st = Settings(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 40, 40, 40) }
        fun label(t: String) = TextView(this).apply { text = t; textSize = 15f; setPadding(0, 28, 0, 4) }.also { col.addView(it) }

        col.addView(TextView(this).apply { text = "Live Translate  中文 → 🌐"; textSize = 22f })
        col.addView(TextView(this).apply {
            text = "1) Permita sobreposição  2) Toque em Iniciar e aceite a captura de tela  3) Abra o jogo/app. " +
                "Nenhuma outra interação é necessária."
        })
        col.addView(Button(this).apply { text = "Iniciar tradução"; setOnClickListener { start() } })
        col.addView(Button(this).apply { text = "Parar"; setOnClickListener { stopService(Intent(this@MainActivity, CaptureService::class.java)) } })

        label("Idioma de destino (origem: chinês)")
        col.addView(Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, langs.map { it.first })
            setSelection(langs.indexOfFirst { it.second == st.target }.coerceAtLeast(0))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { st.target = langs[pos].second }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        })
        fun slider(name: String, min: Int, max: Int, get: () -> Int, set: (Int) -> Unit) {
            val t = label("$name: ${get()}")
            col.addView(SeekBar(this).apply {
                this.max = max - min; progress = get() - min
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { set(p + min); t.text = "$name: ${p + min}" }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            })
        }
        slider("Tamanho da fonte (sp)", 9, 32, { st.fontSp }, { st.fontSp = it })
        slider("Opacidade do fundo (%)", 30, 100, { st.opacity }, { st.opacity = it })
        slider("Posição horizontal (dp)", -60, 60, { st.offsetX }, { st.offsetX = it })
        slider("Posição vertical (dp)", -60, 60, { st.offsetY }, { st.offsetY = it })
        slider("Intervalo de verificação (ms) – maior = menos bateria", 300, 3000, { st.intervalMs }, { st.intervalMs = it })
        slider("Resolução do OCR (%) – menor = menos RAM/CPU (vale ao reiniciar)", 30, 100, { st.ocrScalePct }, { st.ocrScalePct = it })
        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun start() {
        if (!AndroidSettings.canDrawOverlays(this)) {
            Toast.makeText(this, "Permita 'Exibir sobre outros apps' e volte.", Toast.LENGTH_LONG).show()
            startActivity(Intent(AndroidSettings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); return
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        @Suppress("DEPRECATION")
        startActivityForResult(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent(), 1)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req == 1 && res == RESULT_OK && data != null) {
            startForegroundService(Intent(this, CaptureService::class.java).putExtra("code", res).putExtra("data", data))
            moveTaskToBack(true)
        }
    }
}
