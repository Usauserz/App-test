package com.example.livetranslate

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.*

/**
 * Pipeline: captura (MediaProjection, resolução reduzida) -> detecção de mudança (assinatura 48x27)
 * -> OCR -> tradução (cache) -> overlay. Só processa quando a tela muda.
 */
class CaptureService : Service() {
    companion object {
        const val ACTION_STOP = "stop"
        private const val GW = 48; private const val GH = 27
        private const val KEEPALIVE_MS = 4000L
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private lateinit var st: Settings
    private lateinit var engine: TranslationEngine
    private lateinit var wm: WindowManager
    private lateinit var pm: PowerManager
    private lateinit var overlay: OverlayView
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var lastFrame: Bitmap? = null
    private var sw = 0; private var cw = 0

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, id: Int): Int {
        if (i == null || i.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (projection != null) return START_NOT_STICKY
        ServiceCompat.startForeground(this, 1, notif(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        st = Settings(this); engine = TranslationEngine(st)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        pm = getSystemService(PowerManager::class.java)

        @Suppress("DEPRECATION")
        val data = i.getParcelableExtra<Intent>("data")!!
        val mp = getSystemService(MediaProjectionManager::class.java)
            .getMediaProjection(i.getIntExtra("code", 0), data)
        mp.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } },
            Handler(Looper.getMainLooper()))   // obrigatório no Android 14+ antes do VirtualDisplay
        projection = mp

        val m = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(m)
        sw = m.widthPixels
        val scale = st.ocrScalePct / 100f
        cw = (m.widthPixels * scale).toInt(); val ch = (m.heightPixels * scale).toInt()
        reader = ImageReader.newInstance(cw, ch, PixelFormat.RGBA_8888, 2)
        vd = mp.createVirtualDisplay("lt", cw, ch, m.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null)

        overlay = OverlayView(this, st)
        val lp = WindowManager.LayoutParams(-1, -1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT)
        if (Build.VERSION.SDK_INT >= 28)
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        wm.addView(overlay, lp)

        scope.launch { loop() }
        return START_NOT_STICKY
    }

    private suspend fun loop() {
        toast("Preparando modelo de tradução (download único, ~30 MB)…")
        try { engine.prepare() } catch (e: Exception) {
            toast("Falha ao baixar o modelo: ${e.message}"); stopSelf(); return
        }
        toast("Tradução ativa")
        var prev: IntArray? = null
        var lastOcr = 0L
        while (currentCoroutineContext().isActive) {
            delay(st.intervalMs.toLong())
            if (!pm.isInteractive) { delay(2500); continue }          // tela apagada: não gasta bateria
            try {
                var changed = false
                reader?.acquireLatestImage()?.let { img ->            // só chega frame novo se a tela mudou
                    val f = toBitmap(img)
                    val sig = signature(f, overlay.boxes())
                    val p = prev
                    changed = p == null || differs(p, sig)
                    prev = sig
                    setLast(f)
                }
                val now = SystemClock.elapsedRealtime()
                // texto novo pode estar escondido sob o overlay: revalida de tempos em tempos
                val keep = lastOcr == 0L || (overlay.boxes().isNotEmpty() && now - lastOcr > KEEPALIVE_MS)
                if (!changed && !keep) continue
                val frame = grabClean() ?: continue
                lastOcr = SystemClock.elapsedRealtime()
                val items = engine.run(frame)
                val scale = sw.toFloat() / cw
                withContext(Dispatchers.Main) { overlay.submit(items, scale) }
            } catch (e: CancellationException) { throw e
            } catch (e: Exception) { Log.w("LiveTranslate", e) }
        }
    }

    /** Captura sem o overlay por ~100 ms para o OCR não ler a própria tradução. */
    private suspend fun grabClean(): Bitmap? {
        if (overlay.boxes().isEmpty()) return lastFrame
        withContext(Dispatchers.Main) { overlay.alpha = 0f }
        try {
            repeat(6) {
                delay(60)
                reader?.acquireLatestImage()?.let { return toBitmap(it).also { b -> setLast(b) } }
            }
            return null
        } finally { withContext(NonCancellable + Dispatchers.Main) { overlay.alpha = 1f } }
    }

    private fun setLast(b: Bitmap) { val o = lastFrame; lastFrame = b; if (o !== b) o?.recycle() }

    private fun toBitmap(img: Image): Bitmap {
        val w = img.width; val h = img.height
        val pl = img.planes[0]; val pad = pl.rowStride - pl.pixelStride * w
        val b = Bitmap.createBitmap(w + pad / pl.pixelStride, h, Bitmap.Config.ARGB_8888)
        b.copyPixelsFromBuffer(pl.buffer); img.close()
        if (pad == 0) return b
        return Bitmap.createBitmap(b, 0, 0, w, h).also { b.recycle() }
    }

    /** Miniatura em luminância; células cobertas pelo overlay são ignoradas (-1). */
    private fun signature(f: Bitmap, masks: List<Rect>): IntArray {
        val s = Bitmap.createScaledBitmap(f, GW, GH, true)
        val px = IntArray(GW * GH); s.getPixels(px, 0, GW, 0, 0, GW, GH); s.recycle()
        val out = IntArray(px.size) { (Color.red(px[it]) * 30 + Color.green(px[it]) * 59 + Color.blue(px[it]) * 11) / 100 }
        for (r in masks) for (y in (r.top * GH / f.height).coerceAtLeast(0)..(r.bottom * GH / f.height).coerceAtMost(GH - 1))
            for (x in (r.left * GW / f.width).coerceAtLeast(0)..(r.right * GW / f.width).coerceAtMost(GW - 1)) out[y * GW + x] = -1
        return out
    }

    private fun differs(a: IntArray, b: IntArray): Boolean {
        var n = 0
        for (k in a.indices) if (a[k] >= 0 && b[k] >= 0 && Math.abs(a[k] - b[k]) > 12) n++
        return n >= 4
    }

    private fun toast(s: String) = Handler(Looper.getMainLooper()).post { Toast.makeText(this, s, Toast.LENGTH_LONG).show() }

    @Suppress("DEPRECATION")
    private fun notif(): Notification {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("cap", "Tradução ao vivo", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0,
            Intent(this, CaptureService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, "cap").setContentTitle("Tradução ao vivo ativa")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .addAction(android.R.drawable.ic_delete, "Parar", stop).setOngoing(true).build()
    }

    override fun onDestroy() {
        scope.cancel()
        if (::overlay.isInitialized) runCatching { wm.removeView(overlay) }
        vd?.release(); reader?.close(); projection?.stop()
        lastFrame?.recycle()
        if (::engine.isInitialized) engine.close()
        super.onDestroy()
    }
}
